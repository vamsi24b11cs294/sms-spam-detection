# Optional training data

Place your labeled SMS dataset here as `spam.csv` to train the machine-learning classifier. Supported columns are `label,message` or original UCI `v1,v2`. Use labels such as `ham` and `spam`. Do not add private messages, real OTPs, or personal information.

The website works without this file using a clearly identified rule-based fallback.
