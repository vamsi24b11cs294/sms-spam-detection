(function(){
  const input=document.getElementById('message-input');
  const count=document.getElementById('character-count');
  const form=document.getElementById('message-form');
  const search=document.getElementById('conversation-search');
  const emoji=document.getElementById('emoji-button');
  const body=document.getElementById('chat-body');
  if(input&&count){
    const update=()=>{count.textContent=input.value.length+' / 5000';input.style.height='auto';input.style.height=Math.min(input.scrollHeight,130)+'px';};
    input.addEventListener('input',update);update();
    if(form)form.addEventListener('submit',()=>{const btn=form.querySelector('.send-button');btn.disabled=true;btn.innerHTML='<span>…</span>';});
  }
  if(emoji&&input)emoji.addEventListener('click',()=>{input.value+=' 😊';input.dispatchEvent(new Event('input'));input.focus();});
  if(search){search.addEventListener('input',()=>{const q=search.value.toLowerCase();document.querySelectorAll('.recent-conversation').forEach(el=>{el.hidden=!el.textContent.toLowerCase().includes(q)&&!(el.dataset.message||'').toLowerCase().includes(q);});});}
  document.querySelectorAll('.recent-conversation').forEach(el=>el.addEventListener('click',()=>{
    const preview=document.getElementById('selected-message-preview');
    if(!preview)return;
    preview.hidden=false;preview.replaceChildren();
    const title=document.createElement('strong');title.textContent=el.dataset.category||'Message';
    const message=document.createElement('div');message.textContent=el.dataset.message||'';
    const meta=document.createElement('small');meta.textContent='Previous check: '+(el.dataset.prediction||'Unknown')+' · Select the message text to check it again.';
    const copy=document.createElement('button');copy.type='button';copy.className='btn btn-sm btn-outline-primary mt-2';copy.textContent='Use this message';copy.addEventListener('click',()=>{const input=document.getElementById('message-input');input.value=el.dataset.message||'';input.dispatchEvent(new Event('input'));input.focus();});
    preview.append(title,message,meta,copy);if(body)body.scrollTo({top:body.scrollHeight,behavior:'smooth'});
  }));
})();
